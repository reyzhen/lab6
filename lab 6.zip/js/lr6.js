const question = document.getElementById("question");
const imageElement = document.getElementById("image");
const optionButtonsElement = document.getElementById("options-buttons");

// Функция , показывающая текст
function showQuestion(textNodeIndex) {
  
  // Поиск нужного варианта по его id
  const textNode = textNodes.find((textNode) => textNode.id === textNodeIndex);
  
  // Замена текста и изображения на странице
  question.innerText = textNode.text;
  imageElement.src = textNode.src;
  
  // Удаление кнопок
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }
  
  // Перебор количества и текстового содержания для кнопок
  textNode.options.forEach((option) => {
    if (showOption(option)) {
	  // Создание новой кнопки
      const button = document.createElement("button");
	  button.innerText = option.text;
      button.classList.add("btn");
      button.addEventListener("click", () => selectOption(option));
      optionButtonsElement.appendChild(button);
    }
  });
}

// Показ кнопки
function showOption(option) {
  return option.requiredState == null || option.requiredState(state);
}


// Выбор варианта с помощью кнопки
function selectOption(option) {
  const nextTextNodeId = option.nextText;
  showQuestion(nextTextNodeId);
}

// Константа, которая содержит в себе массив, в котором лежат текст, изображение и варианты ответа
const textNodes = [
  {
    id: 1, 									
    text: `Остров в Карибском море. Рассказывают, что гроза пиратского братства капитан Шакал, славившийся жестокостью и хитростью, зарыл здесь свои несметные сокровища... Вы спускаетесь с корабля, куда пойдем?`,
	src: 'Картинки/ship.jpg',
    options: [
      {
        text: `Пойти вперед`,
        nextText: 2,
      },
      {
        text: `Пойти налево`,
        nextText: 3,
      },
      {
        text: `Пойти направо`,
        nextText: 4,
      },
      {
        text: `По диагонали налево`,
        nextText: 5,
      },
      {
        text: `По диагонали направо`,
        nextText: 6,
      },
    ],
  },
  {
    id: 2, 									
    text: `Вы попадаете на пустую поляну. После небольшого отдыха необходимо двигаться дальше.`,
	src: 'Картинки/classic-empty-1.jpg',
    options: [
      {
        text: `Пойти вперед`,
        nextText: 7,
      },
      {
        text: `Пойти налево`,
        nextText: 5,
      },
      {
        text: `Пойти направо`,
        nextText: 6,
      },
      {
        text: `По диагонали налево`,
        nextText: 8,
      },
      {
        text: `По диагонали направо`,
        nextText: 9,
      },
    ],
  },
   {
    id: 3, 									
    text: `На острове нашелся старый маяк, после долгого подъёма по лестнице пирату, который нашел это строение, удается увидеть вдалеке что-то похожее на сундук, отправиться прямо к нему?`,
	src: 'Картинки/classic-lighthouse.jpg',
    options: [
      {
        text: `Да`,
        nextText: 7,
      },
    ],
  },
  {
    id: 4, 									
    text: `В пасть к крокодилу лучше не соваться. Вернитесь туда, откуда пришли.`,
	src: 'Картинки/classic-crocodile.jpg',
    options: [
	  {
        text: `Вернуться на корабль`,
        nextText: 1,
      },
    ],
  },
  {
    id: 5, 									
    text: `Воздушный шар всегда отнесёт вас на ваш корабль`,
	src: 'Картинки/classic-balloon.jpg',
    options: [
	  {
        text: `Вернуться на корабль`,
        nextText: 1,
      },
    ],
  },
  {
    id: 6, 									
    text: `Какая нелепая смерть для пирата — стать обедом тропического людоеда! Пират умирает.`,
	src: 'Картинки/classic-cannibal.jpg',
    options: [
      {
        text: `Начать сначала`,
        nextText: 1,
      },
    ],
  },
  {
    id: 7, 									
    text: `Деньги! Деньги! Деньги! Пиастры и тугрики! Вот они родимые! Поздравляю, вы нашли сокровища! `,
	src: 'Картинки/classic-coins-3.jpg',
    options: [
      {
        text: `Начать сначала`,
        nextText: 1,
      },
    ],
  },
  {
    id: 8, 									
    text: `Вы попадаете на пустую поляну. После небольшого отдыха необходимо двигаться дальше.`,
	src: 'Картинки/arch-b1-empty-1.jpg',
    options: [
      {
        text: `Пойти вперед`,
        nextText: 10,
      },
      {
        text: `Пойти налево`,
        nextText: 11,
      },
      {
        text: `Пойти направо`,
        nextText: 7,
      },
    ],
  },
  {
    id: 9, 									
    text: `Желание пирата проверить, что спрятано в глубине дула пушки — поистине необъяснимо. В расплату за любопытство пират улетает в море в направлении ствола.`,
	src: 'Картинки/classic-gun.jpg',
    options: [
      {
        text: `Начать сначала`,
        nextText: 1,
      },
    ],
  },
  {
    id: 10, 									
    text: `Свезло так свезло. Вы наткнулись на крепость с симпатичной аборигенкой. Вы берете ее в жены и остаетесь жить на острове.`,
	src: 'Картинки/classic-fort-w-aborigine.jpg',
    options: [
      {
        text: `Начать сначала`,
        nextText: 1,
      },
    ],
  },
  {
    id: 11, 									
    text: `Этому пирату чертовски повезло: он нашёл непочатый бочонок рома!`,
	src: 'Картинки/classic-keg.jpg',
    options: [
      {
        text: `Вернуться на поляну`,
        nextText: 8,
      },
      {
        text: `По диагонали направо`,
        nextText: 10,
      },
    ],
  },
];

showQuestion(1);
